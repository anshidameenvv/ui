




export const navbarData=[
    {
       
    routeLink:'dashboard',
    icon:'fa fa-th-large',
    label:'Dashboard'
    },
    {
    routeLink:'product',
    icon:'fa fa-dot-circle-o',
    label:'Product Categories'
    },
    {
     routeLink:'lead management',
    icon:'fa fa-bar-chart',
    label:'Lead management'
    
    },
     {
    
     routeLink:'compagins',
     icon:'fa fa-envelope',
        label:'Compagins'
     },
    {
    
    routeLink:'applications',
    
    icon:'fa fa-pencil',
     label:'Applications'
    },
    {
    routeLink:' my contacts',
    icon:'fa fa-users',
    label:' My contacts'
    },
    {
    routeLink:'claims',
    icon:'fa fa-address-card-o',
    label:'Claims'
    },
    {
    
     routeLink:'twitter',
     icon:'fa fa-twitter',
     label:'Twitter'
    },
     {
       
    routeLink:'settings',
     icon:'fa fa-cog',
    label:'Settings'
    
    },
    {
     routeLink:'darkmode',
     icon:'fa fa-toggle-off',
     label:'Darkmode'
     },
     {
     routeLink:'logout',
     icon:'fa fa-sign-out',
     label:'Logout'
     }
    
    
    
    
    ]
    
    
    